Usage: unpack6589raw.exe <src file> <width> <height> <bitdepth> <Pixel ID>

It will output 2 images, 
1. raw image w/ 2 bytes. 
2. Bmp image w/ simple de-mosaic(bi-linear)
